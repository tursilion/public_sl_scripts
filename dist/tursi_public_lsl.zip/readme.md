(n/a)

Most of these scripts are so old and so specialized that they are of little to no practical value anymore. Many may not even work due to changes in scripting over the years. They are mostly here cause I wanted to back them up. ;)

You have permission to borrow ideas or small portions of code for personal scripts. If you are building something to sell, please ping Tursi.jackson to offer some small compensation. ;)
