# SLTrixie
Trixie's 2014-2015 show from Second Life

These are (most) of the scripts from the SL show, excluding those that belong to others who helped out (this is mostly the fireworks, sun and moon, sorry! :) ).

It also doesn't include the extra scripts from the Halloween show, but really, it was just spinning spheres. ;)

Show stats:

42 scripts (9 unavailable)
7161 lines of code
257KB of text
